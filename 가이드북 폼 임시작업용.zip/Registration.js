import React, { useState } from 'react';
import axios from 'axios';
import './Registration.css';


const Registration = () => {
    const [id, setId] = useState("");
    const [name, setName] = useState("");
    const [detail, setDetail] = useState("");
    const [type1, setType1] = useState("");
    const [type2, setType2] = useState("");
    const [height, setHeight] = useState("");
    const [category, setCategory] = useState("");
    const [gender, setGender] = useState("");
    const [weight, setWeight] = useState("");
    const [characteristic, setCharacteristic] = useState("");
    const [image, setImage] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('serial', id);
        formData.append('name', name);
        formData.append('detail', detail);
        formData.append('type1', type1);
        formData.append('type2', type2);
        formData.append('height', height);
        formData.append('category', category);
        formData.append('gender', gender);
        formData.append('weight', weight);
        formData.append('characteristic', characteristic);
        formData.append('image', image);

        try {
            await axios.post('http://localhost:4001/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <section>

            <div class="registration-container">
                <div class="registration-wrap">
                    <div class="content">
                        {/* <h2 class="content-tit">포켓몬 등록</h2> */}

                        <form onSubmit={handleSubmit}>
                            <div class="content-row1">
                                <label for="id">시리얼넘버</label>
                                <input type="text" id="id" placeholder="No.0000" value={id} onChange={(e) => setId(e.target.value)} />

                                <label for="name">이름</label>
                                <input type="text" id="name" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
                            </div>

                            <div class="content-row2">
                                <label for="defail">상세설명</label>
                                <input type="text" id="defail" placeholder="Detail" value={detail} onChange={(e) => setDetail(e.target.value)} />
                            </div>

                            <div class="content-row3">
                                <label for="type1">타입</label>
                                <input type="text" id="type1" placeholder="Type1" value={type1} onChange={(e) => setType1(e.target.value)} />

                                <label for="type2">타입</label>
                                <input type="text" id="type2" placeholder="Type2" value={type2} onChange={(e) => setType2(e.target.value)} />

                                <label for="category">카테고리</label>
                                <input type="text" id="category" placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
                            </div>

                            <div class="content-row4">
                                <label for="weight">몸무게</label>
                                <input type="text" id="weight" placeholder="Weight" value={weight} onChange={(e) => setWeight(e.target.value)} />

                                <label for="height">높이</label>
                                <input type="text" placeholder="Height" value={height} onChange={(e) => setHeight(e.target.value)} />

                                <label for="gender">성별</label>
                                <input type="text" placeholder="Gender" value={gender} onChange={(e) => setGender(e.target.value)} />
                            </div>



                            <input type="text" placeholder="Characteristic" value={characteristic} onChange={(e) => setCharacteristic(e.target.value)} />
                            <input type="file" onChange={(e) => setImage(e.target.files[0])} />
                            <button type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>

        </section>

    );
};

export default Registration;